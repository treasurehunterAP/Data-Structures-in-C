/*
 ============================================================================
 Name        : a9q2.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

/*
Name        : a9q2.c  public test driver program
Author      : HBF
Version     : 2019-03-16
 */

#include "hash.h"

int htsize = 10;

int main(int argc, char *argv[]) {
  int n = 8;
  if (argc > 1) htsize = atoi(argv[1]);
  if (argc > 2) n = atoi(argv[2]);

  hashtable *ht = new_hashtable(htsize);

  int i;
  char name[10];
  for (i=0; i<n; i++) {
	name[0] = i+'a';
  	name[1] = '\0';
	insert(ht, new_hashnode(name, i));
  }

  printf("hash table after insertion\n");
  display(ht);

  printf("\nsearch data by name %s\n", "a");
  hashnode *hn = search(ht, "a");
  if (hn != NULL) {
    printf("Find data element: (%s, %d)\n", hn->name, hn->value);
  } else {
    printf("Not found\n");
  }

  printf("delete data by name %s\n", "a");
  delete(ht, "a");
  hn = search(ht, "a");
  if (hn != NULL) {
    printf("Find data element: (%s, %d)\n", hn->name, hn->value);
  } else {
    printf("Not found\n");
  }

  display(ht);
  clean_hash(&ht);

  return 0;
}

/*
gcc hash.c a9q2.c -o a9q2
a9q2

 0: (d,3)
 1: (e,4)
 2: (f,5)
 3: (g,6)
 4: (h,7)
 7: (a,0)
 8: (b,1)
 9: (c,2)

search data by name a
Find data element: (a, 0)
delete data by name a
Not found
size:  10
count: 7
hash data:
index: list of the data elements
 0: (d,3)
 1: (e,4)
 2: (f,5)
 3: (g,6)
 4: (h,7)
 8: (b,1)
 9: (c,2)
*/
