#include "hash.h"

int hash(char* word) {
	unsigned int hash = 0, i;
	for (i = 0; word[i] != '\0'; i++) {
		hash = 31 * hash + word[i];
	}
	return hash % htsize;
}

hashnode *new_hashnode(char *name, int value) {
// your implementation
	hashnode *hnp = (hashnode *) malloc(sizeof(hashnode));
	strcpy(hnp->name, name);
	hnp->value = value;
	hnp->next = NULL;
	return hnp;
}

hashtable *new_hashtable(int size) {
// your implementation
	hashtable *ht = (hashtable*) malloc(sizeof(hashtable));
	ht->hnp = (hashnode**) malloc(sizeof(hashnode**) * size);
	ht->size = size;
	ht->count = 0;

	int i;
	for (i = 0; i < size; i++)
		*(ht->hnp + i) = NULL;

	return ht;
}

hashnode *search(hashtable *ht, char *name) {
// your implementation
	int i = hash(name);
	hashnode *hnp = *(ht->hnp + i); //hashnode *hnp = ht->hnp[i];
	if (hnp != NULL) {
		while (hnp != NULL) {
			if (strcmp(name, hnp->name) == 0) // return the first data element matching the key
				return hnp;
			hnp = hnp->next;
		}
	}
	return NULL;
}

int insert(hashtable *ht, hashnode *np) {
// your implementation
	char *name = np->name;
	int i = hash(name);
	hashnode *hnp = *(ht->hnp + i), *prev = NULL;

	if (hnp == NULL) {       // empty linked list
		*(ht->hnp + i) = np; // set new node as the leading node
	} else {
		while (hnp && strcmp(name, hnp->name) != 0) { // ordered by key value for search
			prev = hnp;
			hnp = hnp->next;
		}

		if (strcmp(name, hnp->name) == 0) {
			(*(ht->hnp + i))->value = np->value;
			return 0;
		} else {
		if (prev == NULL)
			*(ht->hnp + i) = np;
		else
			prev->next = np;

		np->next = hnp;

		}
	}

	ht->count++;
	return 1;
}

int delete(hashtable *ht, char *name) {
// your implementation
	int i = hash(name);
	hashnode *hnp = *(ht->hnp + i), *prev = NULL;

	if (hnp != NULL) {
		while (hnp && strcmp(name, hnp->name) != 0) {
			prev = hnp;
			hnp = hnp->next;
		}

		if (hnp && strcmp(name, hnp->name) == 0) {
			if (prev)
				prev->next = hnp->next;
			else
				*(ht->hnp + i) = NULL;

			free(hnp);
			ht->count--;
			return 1;
		}
	}
	return 0;
}

void clean_hash(hashtable **htp) {
	if (*htp == NULL)
		return;
	hashtable *ht = *htp;
	hashnode *sp = ht->hnp[0], *p, *temp;
	int i;
	for (i = 0; i < ht->size; i++) {
		p = ht->hnp[i];
		while (p) {
			temp = p;
			p = p->next;
			free(temp);
		}
		ht->hnp[i] = NULL;
	}
	free(ht->hnp);
	ht->hnp = NULL;
	*htp = NULL;
}

void display(hashtable *ht) {
	int i = 0;
	hashnode *p;
	printf("size:  %d\n", ht->size);
	printf("count: %d\n", ht->count);
	printf("hash data:\nindex: list of the data elements");
	for (i = 0; i < ht->size; i++) {
		p = *(ht->hnp + i);
		if (p)
			printf("\n%2d: ", i);
		while (p) {
			printf("(%s,%d) ", p->name, p->value);
			p = p->next;
		}
	}
	printf("\n");
}

