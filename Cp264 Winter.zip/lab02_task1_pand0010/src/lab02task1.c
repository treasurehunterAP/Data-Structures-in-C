/*
 ============================================================================
 Name        : lab02task1.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */



#include <stdio.h>
#include "functions.h"
int main()
{
double r,side1,side2;
setvbuf(stdout, NULL, _IONBF, 0);
setvbuf(stderr, NULL, _IONBF, 0);
printf("Enter radius to test for circumference and area: ");
scanf("%lf",&r);
printf("The area is %lf, Circumference is %lf ",area(r),circumference(r));
printf("Enter side1 to check hypotenuse function: ");
scanf("%lf",&side1);
printf("Enter side2 to check hypotenuse function: ");
scanf("%lf",&side2);
printf("The hypotenuse calculated is %lf ",hypotenuse(side1,side2));
}
