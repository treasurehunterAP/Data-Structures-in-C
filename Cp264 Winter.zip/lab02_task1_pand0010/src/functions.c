#include <math.h>
#include "functions.h"
#define PI 3.1416 // define PI as a macro value

double circumference(double radius) {
return (2 * PI * radius);
}

double area(double radius) {
return (PI * pow(radius, 2));
}

double hypotenuse(double side1, double side2) {
return (sqrt(pow(side1, 2) + pow(side2, 2)));
}

//=================================

//Save file as main.c

//=================================
