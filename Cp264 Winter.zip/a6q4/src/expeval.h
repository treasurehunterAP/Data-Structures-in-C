#ifndef EXPEVAL_H_
#define EXPEVAL_H_


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include<ctype.h>

typedef struct node {
	int data;
	int type;
	struct node *next;
} NODE;

void infix_to_postfix(char *infixstr, NODE **frontp, NODE **rearp);

int evaluate_postfix(NODE **frontp, NODE **rearp);

int get_priority(char opr);
int is_operator(char op);
int is_symbol(char s);

NODE *new_node(int data, int type);
void display_forward(NODE *start);
void clean(NODE **startp);
NODE *dequeue(NODE **frontp, NODE **rearp);
void enqueue(NODE **frontp, NODE **rearp, NODE *np);
void push(NODE **topp, NODE *np);
NODE *pop(NODE **topp);

#endif /* EXPEVAL_H_ */
