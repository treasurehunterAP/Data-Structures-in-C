/*
 ============================================================================
Name:Eeshaka Senera
ID:sine2040@gmail.com
Email:160930240
WorkID: cp264a6
 ============================================================================
 */
#include "expeval.h"

int main(int argc, char *args[]) {
	char *infix = "9-((3*4)+8)/4";
	if (argc > 1)
		infix = args[1];

	printf("infix: %s\n", infix);

	NODE *front = NULL, *rear = NULL;
	infix_to_postfix(infix, &front, &rear);

	printf("postfix: ");
	display_forward(front);
	printf("\n");

	int val = evaluate_postfix(&front, &rear);
	printf("%s=%d", infix, val);
	return 0;
}
