/*
 ============================================================================
 Name        : lab07_task2_pand0010.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "simple_bst.h"


int main(){

  tnode*root=NULL;
  printf("bst recursive algorithm:");
  iterative_insert(&root, 5);
  iterative_insert(&root, 7);
  iterative_insert(&root, 2);
  iterative_insert(&root, 4);
  iterative_insert(&root, 3);
  iterative_insert(&root, 6);
  iterative_insert(&root, 9);
  iterative_insert(&root, 1);
  iterative_insert(&root, 8);
  print_tree(root, 0);

  int count=leaf_count(root);
  printf("Tree height %d",count);

  return 0;
}
