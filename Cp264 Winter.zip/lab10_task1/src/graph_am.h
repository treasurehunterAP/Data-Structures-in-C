#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAX 10

void randomGraph(int adj[][MAX]);
void displayAdjacentMatrix(int adj[][MAX]);
void breadth_first_search(int adj[][MAX], int visited[], int start);
void depth_first_search(int adj[][MAX], int visited[], int start);
void depth_first_search_recursive(int adj[][MAX], int visited[], int start);
void connected(int adj[][MAX], int node);
