#include "graph_am.h"

void randomGraph(int adj[][MAX]) {
  int i, j, v;
  srand(time(NULL));
  for (i = 0; i < MAX; i++) {
    for (j = 0; j < MAX; j++) {
      if (j == i)
        adj[i][j] = 0;
      else {
        v = rand() % 2;
        adj[i][j] = v;
        adj[j][i] = v;
      }
    }
  }
}

void displayAdjacentMatrix(int adj[][MAX]) {
  int i, j;
  printf("   ");
  for (i = 0; i < MAX; i++)
    printf("%d ", i);
  printf("\n");
  for (i = 0; i < MAX; i++) {
    printf("%d ", i);
    for (j = 0; j < MAX; j++) {
      printf(" %d", adj[i][j]);
    }
    printf("\n");
  }
}

void breadth_first_search(int adj[][MAX], int visited[], int start) {
  int queue[MAX], rear = -1, front = -1, i;
  queue[++rear] = start;
  visited[start] = 1;
  while (rear != front) {
    start = queue[++front];
    printf("%d ", start);
    for (i = 0; i < MAX; i++) {
      if (adj[start][i] == 1 && visited[i] == 0) {
        queue[++rear] = i;
        visited[i] = 1;
      }
    }
  }
}

void depth_first_search(int adj[][MAX], int visited[], int start) {
  int stack[MAX];
  int top = -1, i;
  printf("%d ", start);
  visited[start] = 1;
  stack[++top] = start;
  while (top != -1) {
    start = stack[top];
    for (i = 0; i < MAX; i++) {
      if (adj[start][i] && visited[i] == 0) {
        stack[++top] = i;
        printf("%d ", i);
        visited[i] = 1;
        break;
      }
    }
    if (i == MAX) top--;
  }
}

void depth_first_search_recursive(int adj[][MAX], int visited[], int start) {
  printf("%d ", start);
  visited[start] = 1;
  int i;
  for (i = 0; i < MAX; i++) {
    if (adj[start][i] && visited[i] == 0) {
      depth_first_search_recursive(adj, visited, i);
    }
  }
}

void connected(int adj[][MAX], int node)
{
    printf("Nodes connected to node %d:\n", node);
    int i = 0;
    for(i = 0; i < MAX; ++i)
    {
        if(adj[node][i] == 1)
        {
            printf("%d, ", i);
        }
    }
    printf("\n");
}
