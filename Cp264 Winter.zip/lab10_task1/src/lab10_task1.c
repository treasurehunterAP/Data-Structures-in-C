/*
 ============================================================================
 Name        : lab10_task1.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include "graph_am.h"

int main() {
  int adj[MAX][MAX];
  int visited[MAX];
  int i;

  randomGraph(adj);
  displayAdjacentMatrix(adj);

  printf("\nBFS:\n");
  for (i=0; i<MAX; i++) visited[i] = 0;
  breadth_first_search(adj, visited, 0);

  printf("\nDFS:\n");
  for (i=0; i<MAX; i++) visited[i] = 0;
  depth_first_search(adj,visited,0);

  printf("\nDFS recursion:\n");
  for (i=0; i<MAX; i++) visited[i] = 0;
  depth_first_search_recursive(adj,visited,0);


  connected(adj,0);
  return 0;

}
