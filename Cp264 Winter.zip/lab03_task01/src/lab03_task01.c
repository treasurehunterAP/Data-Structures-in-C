/*
 ============================================================================
 Name        : lab03_task01.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[])
{
	int size = argc - 1;
	int numbers[size];
	for (int i = 0; i < size; i++) {
		numbers[i] = atoi(args[i+1]);
	}
	printf("Index	Value\n");
	for (int j = 0; j < size; j++) {
		printf("%d	%d\n", j, numbers[j]);
	}

	return 0;
}
