Name:Arjun Pandit
ID:170380010
Email:pand0010@mylaurier.ca
WorkID: cp264a8
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1 
1. height, balance_factor, is_avl functions     [5/5/] 
2. rotate_left, rotate_right functions          [5/5/] 
3. insert function                              [4/5/]
4. delete function                              [4/5/]

Q2
1. merge tree function                          [5/5/]
2. merge data function, stats aggregation       [5/5/] 

Total:                                         [28/30/]

Test result:

Q1 output: (copy the screen output of your test run) 
|___3 3.0 4
    |___5 5.0 3
        |___6 6.0 2
            |___7 7.0 1
        |___4 4.0 1
    |___1 1.0 2
        |___2 2.0 1
        |___0 0.0 1
is_val:1
0                     0.0
1                     1.0
2                     2.0
3                     3.0
4                     4.0
5                     5.0
6                     6.0
7                     7.0
|___3 3.0 2
    |___1 1.0 1
is_val:1
1                     1.0
3                     3.0


Q2 output: (copy the screen output of your test run) 

Bodnar                93.6
Chabot                80.4
Costa                 45.1
Dabu                  74.4
Giblett               59.1
Hatch                 66.5
Myrie                 76.7
Smith                 60.1
Suglio                85.7
Sun                   67.7

statistics summary
count          10
mean           70.9
stddev         13.5

Ali                   88.0
Allison               67.7
Eccles                77.8
He                    85.7
Koreck                77.4
Lamont                98.1
Parr                  92.5
Pereira               80.3
Peters                82.3
Wang                  98.1

statistics summary
count          10
mean           84.8
stddev         9.2

Ali                   88.0
Allison               67.7
Bodnar                93.6
Chabot                80.4
Costa                 45.1
Dabu                  74.4
Eccles                77.8
Giblett               59.1
Hatch                 66.5
He                    85.7
Koreck                77.4
Lamont                98.1
Myrie                 76.7
Parr                  92.5
Pereira               80.3
Peters                82.3
Smith                 60.1
Suglio                85.7
Sun                   67.7
Wang                  98.1

statistics summary
count          20
mean           77.9
stddev         13.5

