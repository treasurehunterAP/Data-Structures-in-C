/*
 ============================================================================
 Name        : a8q1.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "avl.h"
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char* args[])
{
	int n = 8;
	if (argc >1)  {
		n = atoi(args[1]);
	}

	TNODE *root = NULL, *np;

	int i;
	char name[20];
	for (i = 0; i < n; i++) {
		itoa(i, name, 10);  //itoa(int value, char *string, int radix)
		// the above may not work on MAC, try the following
		//name[0] = i+ '0';
		//name[1] = '\0';
		insert(&root, name, i+0.0);
	}

	display_tree(root, 0);
	printf("is_val:%d\n", is_avl(root));
	display_inorder(root);

	for (i = 0; i < n; i++) {
		if (i % 2 == 0) {
			itoa(i, name, 10);
			delete(&root, name);
		}
	}
	display_tree(root, 0);
	printf("is_val:%d\n", is_avl(root));
    display_inorder(root);
	clean_tree(&root);
	return 0;
}

/*
gcc avl.c a8q1.c -o a8q1
a8q1
|___3 3.0 4
    |___5 5.0 3
        |___6 6.0 2
            |___7 7.0 1
        |___4 4.0 1
    |___1 1.0 2
        |___2 2.0 1
        |___0 0.0 1
is_val:1
0              0.0
1              1.0
2              2.0
3              3.0
4              4.0
5              5.0
6              6.0
7              7.0
|___5 5.0 3
    |___7 7.0 1
    |___3 3.0 2
        |___1 1.0 1
is_val:1
1              1.0
3              3.0
5              5.0
7              7.0
*/
