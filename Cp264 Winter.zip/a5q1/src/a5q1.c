/*
 Name        : a5q1.c  -- test driver
 Author      : HBF
 Version     : 2019-02-10
 */
#include "llist.h"

int main(int argc, char* args[]) {
	char infilename[40] = "marks.txt";
	char outfilename[40] = "report.txt";
	if (argc > 1) {
		if (argc >= 2) strcpy(infilename, args[1]);
		if (argc >= 3) strcpy(outfilename, args[2]);
	}

	NODE *start = NULL;
	import_data(&start, infilename);
	display(start);

	insert(&start, "Moore", 92.0);
	NODE *p = search(start, "Moore");
	if (p == NULL)
	    printf("Not Fount\n");
	else
		printf("Found:%s, %5.2f\n", p->data.name, p->data.score);
	delete(&start, "Wang");
	report_data(start, outfilename);
	clean(&start);
	return 0;
}
