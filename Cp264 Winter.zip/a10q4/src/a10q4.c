/*
 ============================================================================
 Name        : cp264a10q4.c
 Author      : Arjun Pandit
 Version     :
 Copyright   :
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "puzzle.h"
#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *args[]) {
	char *p;
	int *p1;

	//start state
	state start_state = {
		1, 2, 3,
		4, 5, 6,
		0, 7, 8
	};

//	start_state.height = 0;
//	start_state.parent = NULL;

//	goal state
	state goal = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 0
	};

//	goal.height = 0;
//	goal.parent = NULL;

//	set start/goal states by command line arguments
	if (argc > 1) {
		p1 = start_state.a;
		p = args[1];
		int i = 0;
		while (*p && i < 9) {
			if (*p >= '0' && *p <= '8'){
				*p1++ = *p - '0';
				i++;
			}
			p++;
			if (argc > 2) {
				p1 = goal.a;
				p = args[2];
				int i = 0;
				while (*p && i < 9) {
					if (*p >= '0' && *p <= '8') {
						*p1++ = *p - '0';
						i++;
					}
					p++;
				}
			}
			//check if valid state, ie. has to be a permutation of 0, 1, 2,...,8
			if (is_valid(&start_state) == 0){
				printf("start state is not valid\n");
				return 0;
			}
			else if (is_valid(&goal) == 0){
				printf("goal state is not valid\n");
				return 0;
			}
			else{
				printf("start state\n");
				display_state(&start_state);
				printf("goal state\n");
				display_state(&start_state);
			}
			//check if the start and goal staes have the same parity of inverse pairs
			if (count_inverse(&start_state) % 2 != count_inverse(&goal) % 2){
				printf("no solution\n");
				return 0;
			}
			else {
				printf("solution exists\n");
				breadth_first_search(start_state, goal);
			}

		}
	}
	return 0;
}
