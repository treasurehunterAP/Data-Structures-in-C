/*
 ============================================================================
 Name        : lab3_task2.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[])
{
	int size = argc - 1;
	int numbers[size];
	int index_total = 0;
	int pointer_total = 0;

	for (int i = 0; i < size; i++) {
		numbers[i] = atoi(args[i+1]);
	}
	printf("Index	Value\n");
	for (int j = 0; j < size; j++) {
		printf("    %d	    %d\n", j, numbers[j]);
	}

	for (int k = 0; k < size; k++) {
		index_total += numbers[k];
	}

    int *x = numbers;  // pointer to first element of array

    while (x < numbers + size) {
        pointer_total += *x;
        x++;
    }

	printf("Index Total = %d\n", index_total);

	printf("Pointer Total = %d\n", pointer_total);

	return 0;
}


