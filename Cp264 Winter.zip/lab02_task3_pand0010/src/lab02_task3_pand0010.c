/*
 ============================================================================
 Name        : lab02_task3_pand0010.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
int main(int argc, char *argv[])
{
double radius;
radius=atof(argv[1]);
printf("The volume of the sphere is %lf",volume(radius));


}
