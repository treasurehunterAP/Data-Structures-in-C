#include <math.h>
#include "functions.h"
#define PI 3.1416 // define PI as a macro value

double volume(double radius){
return (((double)4/3)*(PI)*pow(radius,3));
}


