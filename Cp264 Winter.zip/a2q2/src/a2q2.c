/*
 ============================================================================
 Name        : a2q2.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include<stdio.h>
#include<stdlib.h>
#include <math.h>


float horner(float x, int n, float a[]) {
	// your implementation
	int i;
	float result = 0;
	for (i = 0; i <= n; i++) {
		result = result + (a[i] * pow(x, n - i));
		}
	return result;
}



int main(int argc, char* args[]) {
	//get polynomial efficients from command line arguments

	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	if (argc <= 1) {
		printf("Need more than one arguments, e.g.: 1 2 3 4\n");
		return 0;
	}
	int i, n = argc - 1;
	float a[n];
	// declare float array data structure for coefficients
	// read command line arguments convert them to floating numbers atof(args[i+1]);
	for (i = 1; i <= n; i++) {
		a[i] = atof(args[i]);
	}
	// repetitive polynomial evaluation for user input of x value
	float x = 0.0;
	do {
		//get x value from keyboard
		do {
			printf("Please enter x value (Ctrl+C or 999 to quit):\n");
			if (scanf("%f", &x) != 1) {
				printf("Invalid input\n");
			} else {
				break;
			}

			// handle invalid input
			// while(getchar() !='\n') ;
			do {
				if (getchar() == '\n')
					break;
			} while (1);

		} while (1);

		if (x == 999) {
			break;
		}

		for (i = 1; i <= n; i++) {
			if (i == n) {
				printf("%.1f*%.1f^%d= ", a[i], x, n - i);
			} else {
				printf("%.1f*%.1f^%d + ", a[i], x, n - i);
			}
		}
		printf("%.1f\n", horner(x, n, a));



		// escape when input 999
		// print the polynomial expression
		// use x^n to denote x raised to the n-th power
		// use %.1f format for floating number
		// print polynomial by calling horner(x, n, a)

	} while (1);

	return 0;
}


///*
// ============================================================================
// Name        : a2q2.c
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C, Ansi-style
// ============================================================================
// */
//
//#include<stdio.h>
//#include<stdlib.h>
//#include<math.h>
//
//float horner(float x, int n, float a[]) {
//// your implementation
//	int total = 0;
//	for (int i = 0; i <= n; i++) {
//		total = total + (a[i] * pow(x, n - (i + 1)));
//	}
//	return total;
//}
//
//int main(int argc, char* args[]) {
//	//get polynomial efficients from command line arguments
//
//	setvbuf(stdout, NULL, _IONBF, 0);
//	setvbuf(stderr, NULL, _IONBF, 0);
//
//	if (argc <= 1) {
//		printf("Need more than one arguments, e.g.: 1 2 3 4\n");
//		return 0;
//	}
//
//	int i, n = argc - 1;
//	// declare float array data structure for coefficients
//	float a[n];
//	// read command line arguments convert them to floating numbers atof(args[i+1]);
//	for (int j = 1; j <= n; j++) {
//		printf("j = %d\n", j);
//		printf("a = %d\n", args[j]);
//		a[j] = atoi(args[j]);
//
//	}
//
//	// repetitive polynomial evaluation for user input of x value
//	float x = 0.0;
//	do {
//		//get x value from keyboard
//		do {
//			printf("Please enter x value (Ctrl+C or 999 to quit):\n");
//			if (scanf("%f", &x) != 1) {
//				printf("Invalid input\n");
//
//			} else {
//				break;
//
//			}
//
//			// handle invalid input
//			// while(getchar() !='\n') ;
//			do {
//				if (getchar() == '\n')
//					break;
//			} while (1);
//
//		} while (1);
//
//		// escape when input 999
//		if (x == 999) {
//			break;
//		}
//		// print the polynomial expression
//		// use x^n to denote x raised to the n-th power
//		// use %.1f format for floating number
//		for (int p = 1; p <= n; p++) {
//			if (p != n) {
//				printf("%.1f*%.1f^%d +", a[i], x, n - 1);
//			} else {
//				printf("%.1f*%.1f^%d =", a[i], x, n - 1);
//			}
//		}
//		printf("%.1f\n", horner(x, n, a));
//		// print polynomial by calling horner(x, n, a)
//
//	} while (1);
//
//	return 0;
//}


