/*
 ============================================================================
 Name        : lab04_task02.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>


int main ()
{
	FILE *pToFile; // pointer to point to data.txt file

	int id;
	float balance;
	char date[500];
	char fname[500];
	char lname[500];
	float totalbalance=0.0;


	pToFile = fopen ("data.txt", "r");   // opening data.txt file in read mode

	while (fscanf (pToFile, "%d %f %s %s %s", &id, &balance, date, fname, lname)==5)   // reading from data.txt file and checking for EOF, end of file to terminate the loop

		//here we are reading 5 values from each line of file, thus fscanf will keep returning 5 until it will reach end of file
	{
		printf ("%d %.2f %s %s %s\n", id, balance,date, fname, lname);
		totalbalance= totalbalance+balance; // adding balance of record to total balance
	}

	fclose (pToFile); // closing the connection to file

	printf ("Total balance = %.2f",totalbalance);


	return 0;

}
