#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

typedef struct node {
    int value;
    struct node *next;
} Node;

void print(Node *head) {
    if (head != NULL) {
        print(head->next);
        printf("%d ", head->value);
    }
}

int main() {
    Node *head = malloc(sizeof(Node));
    head->value = 4;
    head->next = malloc(sizeof(Node));
    head->next->value = 1;
    head->next->next = malloc(sizeof(Node));
    head->next->next->value = 7;
    head->next->next->next = malloc(sizeof(Node));
    head->next->next->next->value = 9;
    head->next->next->next->next = NULL;

    print(head);    // should print 9 7 1 4
    printf("\n");

    return 0;
}
