/*
 * example: stack by linked list
 * HBF
*/
#include <stdio.h>
#include <malloc.h>

typedef struct node {
  int data;
  struct node *next;
} snode;

void push(snode **topp, int);
void pop(snode **topp);    // pop and free the top element
int peek(snode *top);      // get the data of the top element
snode *pop1(snode **topp); // pop and return the top element (not free)
void pop2(snode **topp, snode**); // pop and pass out the pointer of old top element (not free)
void display_stack(snode *top); // display from top to the bottom.
