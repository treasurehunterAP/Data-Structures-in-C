#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include "lstack.h"


void push(snode **topp, int val) {
  snode *ptr = (snode*) malloc(sizeof(snode));
  ptr->data = val;
  if (*topp == NULL) {
    ptr->next = NULL;
    *topp = ptr;
  } else {
    ptr->next = *topp;
    *topp = ptr;
  }
}

void pop(snode **topp) {
  if (*topp == NULL)
    printf("\nUNDERFLOW");
  else {
    snode *temp = *topp;
    *topp = temp->next;
    free(temp);
  }
}

snode *pop1(snode **topp) {
  if (*topp == NULL)
    return NULL;
  else {
    snode *np = *topp;
    *topp = np->next;
    return np;
  }
}

void pop2(snode **topp, snode **npp) {
  if (*topp == NULL)
    *npp = NULL;
  else {
    snode *np = *topp;
    *topp = np->next;
    *npp = np;
  }
}

int peek(snode *top) {
  if (top == NULL) {
    printf("\nEMPTY");
    return -1;
  }
  else
    return top->data;
}

void display_stack(snode *top) {
  snode *p = top;
  if ( p == NULL)
    printf("\nEMPTY");
  else {
    while (p != NULL) {
      printf("%d\n", p->data);
      p = p->next;
    }
  }
}
