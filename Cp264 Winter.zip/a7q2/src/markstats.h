#ifndef MARKSTATS_H
#define MARKSTATS_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "bst.h"

typedef struct mark_stats {
  TNODE *bst;
  int count;
  float mean;
  float stddev;
} MARKS;

void add_data(MARKS *dataset, char *name, float score);
void remove_data(MARKS *dataset, char *name);

// following functions are from a5q2
void display_stats(MARKS *dataset);
void import_data(MARKS *dataset, char *filename);
void report_data(MARKS *dataset, char *filename);
void print_to_file(TNODE *data, FILE *filename);
char letter_grade(float score);

#endif
