#include "markstats.h"

void add_data(MARKS *sd, char *name, float score) {
	if (search(sd->bst, name) == NULL) {
		insert(&sd->bst, name, score);
		//your code to compute statistics summary after adding new data element
		float meanValue = sd->mean;

		sd->mean = ((sd->mean * sd->count) + score) / (sd->count + 1);
		sd->stddev = sqrt(
				(((sd->count * (sd->stddev * sd->stddev + meanValue * meanValue)
						+ score * score)) / (sd->count + 1))
						- (sd->mean * sd->mean));
		sd->count++;
	} else
		printf("record exit");
}

void remove_data(MARKS *sd, char *name) {
	TNODE *np = NULL;
	if ((np = search(sd->bst, name)) != NULL) {
		float score = np->data.score;
		delete(&sd->bst, name);
		//your code to compute statistics summary after removing a data element
		float meanValue = sd->mean;
		sd->mean = ((sd->mean * sd->count) - score) / (sd->count - 1);
		sd->stddev = sqrt(
				(((sd->count * (sd->stddev * sd->stddev + meanValue * meanValue)
						- score * score)) / (sd->count - 1))
						- (sd->mean * sd->mean));
		sd->count--;


	} else
		printf("record not exit");
}

void display_stats(MARKS *sd) {
	printf("\nstatistics summary\n");
	printf("%-15s%d\n", "count", sd->count);
	printf("%-15s%3.1f\n", "mean", sd->mean);
	printf("%-15s%3.1f\n", "stddev", sd->stddev);

}

void import_data(MARKS *ds, char *filename) {
	char line[40], name[20];
	FILE *fp = fopen(filename, "r");
	char *result = NULL;
	char delimiters[] = ",\n";
	float score = 0;
	int count = 0;
	float mean = 0, stddev = 0;

	if (fp == NULL) {
		perror("Error while opening the file.\n");
		exit(EXIT_FAILURE);
	}

	while (fgets(line, sizeof(line), fp) != NULL) {
		result = strtok(line, delimiters);
		if (result) {
			strcpy(name, result);
			result = strtok(NULL, delimiters);
			score = atof(result);
			count++;
			mean += score;
			stddev += score * score;
			insert(&ds->bst, name, score);
		}
	}

	ds->count = count;
	mean /= count;
	ds->mean = mean;
	ds->stddev = sqrt(stddev / count - mean * mean);

	fclose(fp);
}

void report_data(MARKS *sd, char *filename) {
	FILE *fp = fopen(filename, "w");
	fprintf(fp, "grade report\n");
	print_to_file(sd->bst, fp);
	fprintf(fp, "\nsimple statistics summary\n");
	fprintf(fp, "%-15s%d\n", "count", sd->count);
	fprintf(fp, "%-15s%3.1f\n", "mean", sd->mean);
	fprintf(fp, "%-15s%3.1f\n", "stddev", sd->stddev);
	fclose(fp);

}

void print_to_file(TNODE *root, FILE *fp) {
	if (root) {
		if (root->left)
			print_to_file(root->left, fp);
		fprintf(fp, "%-15s%3.1f%4c\n", root->data.name, root->data.score,
				letter_grade(root->data.score));
		if (root->right)
			print_to_file(root->right, fp);
	}

}

char letter_grade(float s) {
	char r = 'F';
	if (s >= 85)
		r = 'A';
	else if (s >= 70)
		r = 'B';
	else if (s >= 60)
		r = 'C';
	else if (s >= 50)
		r = 'D';
	else
		r = 'F';
	return r;
}
