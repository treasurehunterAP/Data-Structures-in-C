/*
 ============================================================================
 Name        : a8q2.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"
#include "markstats.h"

int main(int argc, char* args[]) {
	char infilename1[40] = "marks.txt.1";
	char infilename2[40] = "marks.txt.2";
	char outfilename[40] = "report.txt";
	if (argc > 1) {
		if (argc >= 2)
			strcpy(infilename1, args[1]);
		if (argc >= 3)
			strcpy(infilename2, args[2]);
		if (argc >= 4)
			strcpy(outfilename, args[3]);
	}

	//create and load data to ds1
	MARKS ds1 = { 0 };
	import_data(&ds1, infilename1);
	display_inorder(ds1.bst);
	display_stats(&ds1);

	//create and load data to ds2
	MARKS ds2 = { 0 };
	import_data(&ds2, infilename2);
	display_inorder(ds2.bst);
	display_stats(&ds2);

	merge_data(&ds1, &ds2);
	clean_tree(&ds2.bst); //clean ds2 bst data

	display_inorder(ds1.bst);
	display_stats(&ds1);
	report_data(&ds1, outfilename);
	clean_tree(&ds1.bst);
	return 0;
}

/*
 gcc avl.c markstats.c a8q2.c -o a8q2
 a8q2
 Bodnar         93.6
 Chabot         80.4
 Costa          45.1
 Dabu           74.4
 Giblett        59.1
 Hatch          66.5
 Myrie          76.7
 Smith          60.1
 Suglio         85.7
 Sun            67.7

 statistics summary
 count          10
 mean           70.9
 stddev         13.5
 Ali            88.0
 Allison        67.7
 Eccles         77.8
 He             85.7
 Koreck         77.4
 Lamont         98.1
 Parr           92.5
 Pereira        80.3
 Peters         82.3
 Wang           98.1

 statistics summary
 count          10
 mean           84.8
 stddev         9.2
 Ali            88.0
 Allison        67.7
 Bodnar         93.6
 Chabot         80.4
 Costa          45.1
 Dabu           74.4
 Eccles         77.8
 Giblett        59.1
 Hatch          66.5
 He             85.7
 Koreck         77.4
 Lamont         98.1
 Myrie          76.7
 Parr           92.5
 Pereira        80.3
 Peters         82.3
 Smith          60.1
 Suglio         85.7
 Sun            67.7
 Wang           98.1

 statistics summary
 count          20
 mean           77.9
 stddev         13.5

 */
