#include "markstats.h"

void merge_tree(TNODE **rootp1, TNODE **rootp2) {
// your implementation
	if (*rootp2) {
		insert(rootp1, (*rootp2)->data.name, (*rootp2)->data.score);
		if ((*rootp2)->left)
			merge_tree(&(*rootp1), &(*rootp2)->left);
		if ((*rootp2)->right)
			merge_tree(&(*rootp1), &(*rootp2)->right);
	}

}

void merge_data(MARKS *ds1, MARKS *ds2) {
// your implementation
	merge_tree(&ds1->bst, &ds2->bst);
	int new_count = ds1->count + ds2->count;
	float old_mean_ds1 = ds1->mean;
	float old_mean_ds2 = ds2->mean;
	float new_mean = ((ds1->count * ds1->mean) + (ds2->count * ds2->mean))
			/ new_count;
	float new_stddev = sqrt(
			(((ds1->stddev * ds1->stddev + old_mean_ds1 * old_mean_ds1)
					* ds1->count
					+ (ds2->stddev * ds2->stddev + old_mean_ds2 * old_mean_ds2)
							* ds2->count) / new_count) - (new_mean * new_mean));
	ds1->count = new_count;
	ds1->mean = new_mean;
	ds1->stddev = new_stddev;

}

// the following are adapted from markstats.c of a7q2

void display_stats(MARKS *sd) {
	printf("\nstatistics summary\n");
	printf("%-15s%d\n", "count", sd->count);
	printf("%-15s%3.1f\n", "mean", sd->mean);
	printf("%-15s%3.1f\n", "stddev", sd->stddev);
	printf("\n");
}

void add_data(MARKS *sd, char *name, float score) {
	//printf("-%s %f\n", name, score);
	//TNODE *a = search(sd->bst, name);
	//printf("%s %f\n", a->data.name, a->data.score);
	if (search(sd->bst, name) == NULL) {
		insert(&sd->bst, name, score);
		//update statistics summary by adding a new data
		int count = sd->count;
		float mean = sd->mean;
		float stddev = sd->stddev;
		sd->count = count + 1;
		sd->mean = (mean * count + score) / (count + 1);
		sd->stddev = sqrt(
				score * score / (count + 1.0)
						+ (stddev * stddev + mean * mean)
								* (count / (count + 1.0))
						- sd->mean * sd->mean);
	} else
		printf("record exit\n");
}

void remove_data(MARKS *sd, char *name) {
	TNODE *np = NULL;
	if ((np = search(sd->bst, name)) != NULL) {
		float score = np->data.score;
		delete(&sd->bst, name);

		//update statistics summary after removing an old one
		int count = sd->count;
		float mean = sd->mean;
		float stddev = sd->stddev;
		sd->count = count - 1;
		sd->mean = (mean * count - score) / (count - 1.0);
		sd->stddev = sqrt(
				(stddev * stddev + mean * mean) * (count / (count - 1.0))
						- score * score / (count - 1.0) - sd->mean * sd->mean);
	} else
		printf("record not exit\n");
}

void import_data(MARKS *ds, char *filename) {
	char line[40], name[20];
	FILE *fp = fopen(filename, "r");
	char *result = NULL;
	char delimiters[] = ",\n";
	float score = 0;
	int count = 0;
	float mean = 0, stddev = 0;

	if (fp == NULL) {
		perror("Error while opening the file.\n");
		exit(EXIT_FAILURE);
	}

	while (fgets(line, sizeof(line), fp) != NULL) {
		result = strtok(line, delimiters);
		if (result) {
			strcpy(name, result);
			result = strtok(NULL, delimiters);
			score = atof(result);
			count++;
			mean += score;
			stddev += score * score;
			insert(&ds->bst, name, score);
		}
	}

	ds->count = count;
	mean /= count;
	ds->mean = mean;
	ds->stddev = sqrt(stddev / count - mean * mean);

	fclose(fp);
}

void report_data(MARKS *sd, char *filename) {
	FILE *fp = fopen(filename, "w");
	fprintf(fp, "grade report\n");
	print_to_file(sd->bst, fp);
	fprintf(fp, "\nsimple statistics summary\n");
	fprintf(fp, "%-15s%d\n", "count", sd->count);
	fprintf(fp, "%-15s%3.1f\n", "mean", sd->mean);
	fprintf(fp, "%-15s%3.1f\n", "stddev", sd->stddev);
	fclose(fp);
}

void print_to_file(TNODE *root, FILE *fp) {
	if (root) {
		if (root->left)
			print_to_file(root->left, fp);
		fprintf(fp, "%-15s%3.1f%4c\n", root->data.name, root->data.score,
				letter_grade(root->data.score));
		if (root->right)
			print_to_file(root->right, fp);
	}
}

char letter_grade(float s) {
	char r = 'F';
	if (s >= 85)
		r = 'A';
	else if (s >= 70)
		r = 'B';
	else if (s >= 60)
		r = 'C';
	else if (s >= 50)
		r = 'D';
	else
		r = 'F';
	return r;

}
