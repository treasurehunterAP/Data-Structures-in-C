#ifndef MARKSTATS_H_
#define MARKSTATS_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "avl.h"

typedef struct mark_stats {
	TNODE *bst;
	int count;
	float mean;
	float stddev;
} MARKS;

/* merge tree rootp2 into tree rootp1 */
void merge_tree(TNODE **rootp1, TNODE **rootp2);

/* merget two MARKS dataset and aggregate stats info */
void merge_data(MARKS *ds1, MARKS *ds2);

// the following functions are from markstats.c of a7q2
void display_stats(MARKS *dataset);
void add_data(MARKS *dataset, char *name, float score);
void remove_data(MARKS *dataset, char *name);
void import_data(MARKS *dataset, char *filename);
void report_data(MARKS *dataset, char *filename);
void print_to_file(TNODE *data, FILE *filename);
char letter_grade(float score);


#endif /* MARKSTATS_H_ */

