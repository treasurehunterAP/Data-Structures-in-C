/*
 Name        : a5q2.c -- test driver program
 Author      : HBF
 Version     : 2019-02-10
 */
#include "dllist.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* args[]) {
  NODE *start = NULL, *end = NULL;
  int i=0;
  for (i = 0; i<10; i++) {
    insert_start(&start, &end, new_node('0'+i));
  }
  display_forward(start);
  printf("\n");
  display_backward(end);
  delete_start(&start, &end);
  delete_end(&start, &end);
  printf("\n");
  display_forward(start);
  clean(&start, &end);

  for (i = 0; i<10; i++) {
    insert_end(&start, &end, new_node('a'+i));
  }
  printf("\n");
  display_forward(start);
  clean(&start, &end);
  return 0;
}
