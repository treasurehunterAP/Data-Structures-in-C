/*
 ============================================================================
 Name        : a1q3.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Write a C program, named a1q3.c, to solve the quadratic equation ax^2 + b x + c = 0 of given coefficients a, b and c.
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>

#include <math.h>  // need this library for maths functions fabs() and sqrt()

int main()
{
	setbuf(stdout,NULL);
    float a, b, c, d, x1, x2;
    int inn;
    char temp;
    printf("Working");

    do {  // do-while for new input problem
        // do-while loop to get correct input of three floating numbers,
        do {
            printf("Please enter the coefficients a,b,c:\n");
            inn = scanf("%f,%f,%f", &a,&b,&c);

            if (inn != 3 ) {
               printf("Invalid input\n");
            } else
                break;

              do {  // flush the input buffer
                scanf("%c", &temp);
                if (temp == '\n') break;
              } while (1);

        } while (1);

        if (fabs(a) < 1e-6 && fabs(b) < 1e-6 && fabs(c) < 1e-6) {
            printf("Goodbye\n");
            break;
        }
        else if (fabs(a) < 1e-6) {
            printf("not a quadratic equation\n");
        }
        else {
            d = (b * b) - (4 * a * c);  // compute the discriminant
            x1=(-b+sqrt(d)/(2*a));
            x2=(-b-sqrt(d)/(2*a));
            if (d>0){
            	printf("The root are %.6f and %.6f",x1,x2);
            }else if (d<0){
            	x2=(sqrt(d*-1)/(2*a));
            	x1=-b/(2*a);
            	printf("%.6f + %.6fi\n",x1,x2);
            	printf("%.6f - %.6fi\n",x1,x2);
            }else{
            	printf("The root is %.6f",x1);

            }


            // your solution logic

        }

    } while (1);
    return 0;
}
