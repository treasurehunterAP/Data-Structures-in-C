#include <stdio.h>
#include <malloc.h>

typedef struct node {
  int data;
  struct node *next;
} QNODE;

void enqueue(QNODE **frontp, QNODE **rearp, int);
int dequeue(QNODE **frontp, QNODE **rearp);
int peek(QNODE *front);
void clean(QNODE **frontp, QNODE **rearp);
