/*
 ============================================================================
Name:Eeshaka Senera
ID:sine2040@gmail.com
Email:160930240
WorkID: cp264a6
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#include "queue.h"

int main(int argc, char* args[]) {
  QNODE *front = NULL, *rear = NULL;
  int i=0;
  for (i=1; i<=12; i++) {
    enqueue(&front, &rear, i);
  }

  printf("%d ", peek(front));
  dequeue(&front, &rear);
  printf("%d ", dequeue(&front, &rear));
  printf("\n");
  while (front != NULL) {
    printf("%d ", dequeue(&front, &rear));
  }

  for (i=1; i<=12; i++) {
    enqueue(&front, &rear, i);
  }
  clean(&front, &rear);

  return 0;
}
