#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
GRAPH *new_graph(int vertex_number) {
	GRAPH* new_g = (GRAPH*)malloc(sizeof(GRAPH));
	new_g->order=vertex_number;
	new_g->adjlist=(ADJNODE**)malloc(vertex_number*sizeof(ADJNODE));
	new_g->size=0;
	for(int i=0;i<vertex_number;i++){
		new_g->adjlist[i]=NULL;
	}
	return new_g;
}

void add_edge(GRAPH *g, int from, int to, int weight) {
	ADJNODE * ptr = g->adjlist[from], *prev = NULL;
	ADJNODE * new_node = (ADJNODE*) malloc(sizeof(ADJNODE));
	new_node->vertex=to;
	new_node->weight=weight;
	new_node->next=NULL;
	if(ptr==NULL){
		g->adjlist[from]=new_node;
	}else{
		while(ptr!=NULL){
			if(ptr->vertex!=from){
				prev=ptr;
				ptr=ptr->next;
			}
		}
		if(prev==NULL){
			g->adjlist[from]=new_node;
		}else{
			prev->next=new_node;
		}
	}
	g->size=g->size+1;
}

int get_weight(GRAPH *g, int from, int to) {
	ADJNODE *ptr = g->adjlist[from];
	//ADJNODE *prev = NULL;
	int exists = 0;
	if(ptr == NULL)
	{
		return INFINITY;
	}
	else
	{
		while(ptr)
		{
			if(ptr->vertex == to)
			{
				exists = 1;
				break;
			}
			//prev = ptr;
			ptr = ptr->next;
		}
		if(exists == 1)
		{
			return ptr->weight;
		}
		else
			return INFINITY;
	}
}

void clean_graph(GRAPH **gp) {
	int i;
	ADJNODE* temp, *ptr;
	for(i=0;i<(*gp)->order;i++){
		ptr=(*gp)->adjlist[i];
		while(ptr!=NULL){
			temp=ptr;
			ptr=ptr->next;
			free(temp);
		}
		(*gp)->adjlist[i]=NULL;
	}
}

void display_graph(GRAPH *g) {
	if (g == NULL) return;
	printf("\nweighted graph in adjacency list");
	printf("\norder: %d", g->order);
	printf("\nsize: %d", g->size);
	printf("\nnode from: (to weight)");
	int i;
	ADJNODE *ptr;
	for (i = 0; i < g->order; i++) {
		printf("\nnode %d:", i);
		ptr = g->adjlist[i];
		while (ptr != NULL) {
			printf(" (%d, %d)", ptr->vertex, ptr->weight);
			ptr = ptr->next;
		}
	}
}
