/*
 ============================================================================
 Name        : lab09_tak21.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "heap.h"

int main(int argc, char *args[]) {
	//  int Heap[MAX];
	int *Heap = malloc(MAX * sizeof Heap);
	int n = 20;
	if (argc >1) n = atoi(args[1]);

	int i;
	for (i = 0; i < n; i++) {
		insert(&Heap, i);
	}
	display_heap(Heap);

	for (i = 0; i < n; i++) {
		printf("%d ", find_max(Heap));
		delete(Heap);
	}
	printf("\n");

	for (i = 0; i < n; i++) {
		insert(&Heap, n-i-1);
	}

	heap_sort_heap(Heap);
	display_array(Heap, n);

	//in place heap sort,
	int a[n];
	for (i = 0; i < n; i++) {
		a[i] = rand()%20;
	}
	printf("Before heap sort:\n");
	for (i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	printf("\n");
	heap_sort_array(a, n);
	printf("After heap sort:\n");
	for (i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}
