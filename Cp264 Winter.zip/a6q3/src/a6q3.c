/*
 ============================================================================
Name:Eeshaka Senera
ID:sine2040@gmail.com
Email:160930240
WorkID: cp264a6
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include<malloc.h>

int main(int argc, char* args[]) {
  SNODE *top = NULL;
  int i=0;
  for (i=1; i<=12; i++) {
    push(&top, i);
  }

  printf("%d ", peek(top));
  pop(&top);
  printf("%d ", peek(top));
  printf("\n");

  while (top != NULL) {
    printf("%d ", peek(top));
    pop(&top);
  }

  for (i=1; i<=12; i++) {
    push(&top, i);
  }
  clean(&top);
  while (top != NULL) {
    printf("%d ", peek(top));
    pop(&top);
  }

  return 0;
}
