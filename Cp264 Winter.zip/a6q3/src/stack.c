#include "stack.h"
#include <stdlib.h>
void push(SNODE **topp, int value) {
SNODE* n = (SNODE*) malloc(sizeof(SNODE));
n->data = value;
n->next = *topp;
*topp = n;
}

void pop(SNODE **topp) {
SNODE *temp = *topp;
if(temp != NULL){
*topp = temp->next;
free(temp);
}
}

int peek(SNODE *top) {
return top->data;
}

void clean(SNODE **topp) {
while(*topp)
pop(topp);
}
