/*
 ============================================================================
 Name        : lab04task03.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#define ARRAY_SIZE 120
int main(void) {
	setbuf(stdout, NULL);
	FILE *fp = NULL;
	char *filename = "C:\\cp264\\lab04_task03\\data (3).csv";
	char comma[] = ",\0";
	char *token;
	char line[ARRAY_SIZE];
	int i = 0, j = 0;
	char str1[10], str2[10], date[20];
	int id;
	float amount = 0, total = 0.0;

	fp = fopen(filename, "r");
	if (fp == NULL) {
		printf("\nCannot open file '%s'.\n", filename);
	} else {
		while (fgets(line, ARRAY_SIZE, fp) != NULL) {
			token = strtok(line, comma);
			id = atoi(token);
			token = strtok(NULL, comma);
			amount = atof(token);
			total += amount;
			token = strtok(NULL, comma);
			strncpy(date, token, 20);
			token = strtok(NULL, comma);
			strncpy(str1, token, 10);
			token = strtok(NULL, comma);
			strncpy(str2, token, 10);
			printf("%d %.2f %s %s %s\n", id, amount, date, str1, str2);
		}
		printf("\nThe total of the balances is: $%.2f", total);
		fclose(fp);
	}
	return 0;

}
