/*
 ============================================================================
 Name        : a1q2.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description :  reads a positive integer n from command line argument, and computes and prints the factorials i!, for i from 1 to n.
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[])
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    int i, n=0,f=1,value;
    if ( argc > 1 ) {
    	n = atoi( args[1] );  // convert a number string to an integer
    	if (n>=1){
    		for (i=1;i<=n;i++){
    			value=f;
    			f*=i;
    			if (value!=f/i){
    				printf("Overflow at %d!\n",i);
    				break;
   			}

    			printf("%11d",f);
    			if (i %4==0)
    				printf("\n");

    		}


    	} else{
    		printf("Invalid Argument\n");
    	}

    // your program logic

    }
    else
        printf("no argument");

    return 0;
}
