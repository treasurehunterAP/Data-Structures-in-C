#include <stdio.h>
#include <stdlib.h>
#include "tree_avl.h"

int max(int a, int b)
{
  return (a > b)? a : b;
}

int height(tnode *root)
{
  if (root == NULL)
    return 0;
  else
    return root->height;
}

tnode *new_node(int key)
{
  tnode* node = (tnode*) malloc(sizeof(tnode));
  node->key = key;
  node->left = NULL;
  node->right = NULL;
  node->height = 1;
  return(node);
}

tnode *rotate_right(tnode *y)
{
  tnode *x = y->left;
  tnode *T2 = x->right;

  // Perform rotation
  x->right = y;
  y->left = T2;

  // Update heights
  y->height = max(height(y->left), height(y->right))+1;
  x->height = max(height(x->left), height(x->right))+1;

  // Return new root
  return x;
}

tnode *rotate_left(tnode *x)
{
  tnode *y = x->right;
  tnode *T2 = y->left;

  // Perform rotation
  y->left = x;
  x->right = T2;

  //  Update heights
  x->height = max(height(x->left), height(x->right))+1;
  y->height = max(height(y->left), height(y->right))+1;

  // Return new root
  return y;
}

int balance_factor(tnode *np)
{
  if (np == NULL)
    return 0;
  return
    height(np->left) - height(np->right);
}

tnode *insert(tnode *root, int key)
{
  /* 1.  Perform the normal BST rotation */
  if (root == NULL)
    return(new_node(key));

  if (key < root->key)
    root->left = insert(root->left, key);
  else if (key > root->key)
    root->right = insert(root->right, key);
  else // Equal keys not allowed
    return root;

  /* 2. Update height of this ancestor node */
  root->height = 1 + max(height(root->left), height(root->right));

  /* 3. Get the balance factor of this ancestor
    node to check whether this node became
    unbalanced */
  int bf = balance_factor(root);

  // If this node becomes unbalanced, then there are 4 cases

  // Case 1
  if (bf == 2 && balance_factor(root->left) >= 0) {
    return rotate_right(root);
  }
  // Case 2
  if (bf == 2 && balance_factor(root->left) < 0)
  {
    root->left = rotate_left(root->left);
    return rotate_right(root);
  }
  // Case 3
  if (bf == -2 && balance_factor(root->right) <= 0)
    return rotate_left(root);

  // Case 4
  if (bf == -2 && balance_factor(root->right) > 0)
  {
    root->right = rotate_right(root->right);
    return rotate_left(root);
  }

  return root;
}

tnode *get_smallest_node(tnode *root)
{
  tnode *tnp = root;
  while (tnp->left != NULL)
    tnp = tnp->left;
  return tnp;
}

tnode *delete(tnode* root, int key)
{
  // STEP 1: PERFORM STANDARD BST DELETE
  if (root == NULL)
    return root;

  if ( key < root->key )
    root->left = delete(root->left, key);

  else if( key > root->key )
    root->right = delete(root->right, key);

  else  // key == root->key
  {
    // node with only one child or no child
    if( (root->left == NULL) || (root->right == NULL) )
    {
      tnode *temp = root->left ? root->left : root->right;

      // No child
      if (temp == NULL)
      {
        temp = root;
        root = NULL;
      }
      else // One child
      {
        *root = *temp; // Copy the contents of
      }
     // the non-empty child
      free(temp);
    }
    else
    {
    // node with two children: Get the inorder
    // successor (smallest in the right subtree)
      tnode* temp = get_smallest_node(root->right);

    // Copy the inorder successor's data to this node
      root->key = temp->key;

    // Delete the inorder successor
      root->right = delete(root->right, temp->key);
    }
  }

  // If the tree had only one node then return
  if (root == NULL)
    return root;

  // STEP 2: UPDATE HEIGHT OF THE CURRENT NODE
  root->height = 1 + max(height(root->left), height(root->right));

  // STEP 3: GET THE BALANCE FACTOR OF THIS NODE (to
  // check whether this node became unbalanced)
  int bf = balance_factor(root);

  // If this node becomes unbalanced, then there are 4 cases

  // Case 1
  if (bf == 2 && balance_factor(root->left) >= 0) {
    return rotate_right(root);
  }
  // Case 2
  if (bf == 2 && balance_factor(root->left) < 0)
  {
    root->left =  rotate_left(root->left);
    return rotate_right(root);
  }
  // Case 3
  if (bf== -2 && balance_factor(root->right) <= 0)
    return rotate_left(root);

  // Case 4
  if (bf == -2 && balance_factor(root->right) > 0)
  {
    root->right = rotate_right(root->right);
    return rotate_left(root);
  }

  return root;
}

void print_preorder(tnode *root)
{
  if(root != NULL)
  {
    printf("%d ", root->key);
    print_preorder(root->left);
    print_preorder(root->right);
  }
}

void print_tree(tnode *root, int prelen) {
  int i;
  if (root != NULL) {
    for (i = 0; i < prelen; i++)
      printf("%c", ' ');
    printf("%s", "|___");
    printf("%d\n", root->key);
    print_tree(root->right, prelen + 4);
    print_tree(root->left, prelen + 4);

  }
}
int node_count( struct tnode *root) {
    if (root == NULL) {
        return 0;
    } else {
        return 1 + node_count(root->left) + node_count(root->right);
    }
}

int is_balanced(struct tnode *root)
{
int lh; /* for height of left subtree */
int rh; /* for height of right subtree */

/* If tree is empty then return true */
if(root == NULL)
return 1;

/* Get the height of left and right sub trees */
lh = height(root->left);
rh = height(root->right);

if( abs(lh-rh) <= 1 &&
is_balanced(root->left) &&
is_balanced(root->right))
return 1;

/* If we reach here then tree is not height-balanced */
return 0;
}
