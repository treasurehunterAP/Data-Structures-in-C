#include "dllist.h"
#include "bigint.h"

BIGINT add(BIGINT opointer1, BIGINT opointer2) {
	BIGINT sum = { 0 };
	int carry = 0;
	int digit = 0;
	NODE *pointer1 = opointer1.end;
	NODE *pointer2 = opointer2.end;

	while (pointer1 != NULL && pointer2 != NULL) {
		digit = pointer1->data + pointer2->data + carry;
		carry = 0;
		if (digit > 9) {
			carry = 1;
			digit -= 10;
		}
		insert_start(&sum.start, &sum.end, new_node(digit));
		pointer1 = pointer1->prev;
		pointer2 = pointer2->prev;
	}

	while (pointer1 != NULL) {
		digit = pointer1->data + carry;
		carry = 0;
		insert_start(&sum.start, &sum.end, new_node(digit));
		if (digit > 9) {
			carry = 1;
			digit -= 10;
		}
		pointer1 = pointer1->prev;
	}
	while (pointer2 != NULL) {
		digit = pointer2->data + carry;
		carry = 0;
		insert_start(&sum.start, &sum.end, new_node(digit));
		if (digit > 9) {
			carry = 1;
			digit -= 10;
		}
		pointer2 = pointer2->prev;
	}
	if (carry == 1) {
		insert_start(&sum.start, &sum.end, new_node(1));
	}
	return sum;
}

BIGINT Fibonacci(int n) {
	BIGINT a = { 0 };
	BIGINT b = { 0, new_node(1) };
	BIGINT c;
	BIGINT flag = { 0 };
	if (n <= 0) {
		flag = a;
	} else {
		for (int i = 1; i < n; i++) {
			c = add(a, b);
			a = b;
			b = c;
		}
		flag = c;
	}
	return flag;
}


BIGINT bigint(char *p) {
	BIGINT bigIntVal = { 0 };
    if (p == NULL)
        return bigIntVal;
    else if (!(*p > '0' && *p <= '9')) {
        return bigIntVal;
    }
    while (*p) {
      if (*p >= '0' && *p <= '9' ){
			insert_end(&bigIntVal.start, &bigIntVal.end, new_node(*p - '0'));
      } else {
			clean_bigint(&bigIntVal);
			insert_end(&bigIntVal.start, &bigIntVal.end, new_node('0'));
         break;
      }
      p++;
    }
	return bigIntVal;
}

void display_bigint(BIGINT bignumber) {
  NODE *ptr = bignumber.start;
  while ( ptr != NULL) {
    printf("%d", ptr->data);
    ptr = ptr->next;
  }
}

void clean_bigint(BIGINT *bignumberp) {
  clean(&bignumberp->start, &bignumberp->end);
}
