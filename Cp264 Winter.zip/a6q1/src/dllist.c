#include "dllist.h"

NODE *new_node(char data) {
  NODE *np = (NODE*) malloc(sizeof(NODE));
  np->data = data;
  np->prev = NULL;
  np->next = NULL;
  return np;
}

void insert_start(NODE **startp, NODE **endp, NODE *new_np) {
  if (*startp == NULL) {
    new_np->prev = NULL;
    new_np->next = NULL;
    *startp = new_np;
    *endp = new_np;
  } else {
    new_np->prev = NULL;
    new_np->next = *startp;
    (*startp)->prev = new_np;
    *startp = new_np;
  }
}

void insert_end(NODE **startp, NODE **endp, NODE *new_np) {
  if (*startp == NULL) {
    *startp = new_np;
    new_np->prev = NULL;
  } else {
    (*endp)->next = new_np;
    new_np->prev = *endp;
  }
  *endp = new_np;
  new_np->next = NULL;
}

void delete_start(NODE **startp, NODE **endp) {
  NODE *ptr = *startp;
  if ( ptr != NULL) {
    if (ptr == *endp) {
       *startp = NULL;
       *endp = NULL;
    }
    else {
      *startp = ptr->next;
      (*startp)->prev = NULL;
    }
    free(ptr);
  }
}

void delete_end(NODE **startp, NODE **endp) {
  NODE *ptr = *endp;
  if ( ptr != NULL) {
    if (ptr == *startp) {
      *startp = NULL;
      *endp = NULL;
    }
    else {
      *endp = ptr->prev;
      (*endp)->next = NULL;
    }
    free(ptr);
  }
}

void display_forward(NODE *np) {
  while ( np!= NULL) {
    printf("%c ", np->data);
    np = np->next;
  }
}

void display_backward(NODE *np) {
  while (np != NULL) {
    printf("%c ", np->data);
    np = np->prev;
  }
}

void clean(NODE **startp, NODE **endp) {
  NODE *temp, *np = *startp;
  while (np != NULL) {
    temp = np;
    np = np->next;
    free(temp);
  }
  *startp = NULL;
  *endp = NULL;
}
