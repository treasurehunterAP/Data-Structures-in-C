/*
 ============================================================================
Name:Eeshaka Senera
ID:sine2040@gmail.com
Email:160930240
WorkID: cp264a6
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#include "dllist.h"
#include "bigint.h"

int main(int argc, char* args[]) {
  //get input
  char *opr1 = "1111111111111111111";
  char *opr2 = "8888888888888888889";
  int n = 100;
  if (argc > 1) opr1 = args[1];
  if (argc > 2) opr2 = args[2];
  if (argc > 3 ) n = atoi(args[3]);

  //test add() function
  BIGINT a = bigint(opr1);
  BIGINT b = bigint(opr2);
  BIGINT s = add(a, b);
  display_bigint(a);
  printf("%c", '+');
  display_bigint(b);
  printf("=");
  display_bigint(s);
  clean_bigint(&a);
  clean_bigint(&b);
  clean_bigint(&s);

  //test Fibonacci()
  printf("\nFibonacci(%d)=", n);
  s = Fibonacci(n);
  display_bigint(s);
  clean_bigint(&s);

  return 0;
}
