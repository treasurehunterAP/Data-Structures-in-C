/*
 ============================================================================
 Name        : lab06_task1_pand0010.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
#include<stdlib.h>
#include<ctype.h>

#define size sizeof(char)*100

//Prototype declaration..
void strnclean(char *target, const char *source);

int main( void )
{
    char *source = NULL;        //Source
    char *target = NULL;            //Target
    //Dynamic Memory allocation..
    target = (char *) malloc (size * sizeof (char));
    source = (char *) malloc (size * sizeof (char));

    printf("\n\n Enter the string : ");
    fgets(source, size, stdin); //Read string 1...

    //Func call to get the target..
    strnclean(target, source);
    printf("\n Source : %s" , source);
    printf("\n Target : %s\n\n" , target);

    free(source);
    free(target);
return 0;
}

/**
* Function takes two strings as parameters, target and sourcei..
* Using the ctype library, copy only the alphabetic characters
   from source to target, and make the characters lower case
*/

void strnclean(char *target, const char *source)
{
    int i = 0;
    int j = 0;
    int count =0;       //Counts the length of continuos mnatching chars
    char c;
    //Travesing the source char by char..
    for (i = 0; *(source + i) != '\0' ; i++) {

        c = (*(source + i));

        //Returns non-zero (true) if c is a digit character, zero else.
        if(isdigit(c))
            continue;
        //Returns non-zero (true) if c is punctuation character, else zero.
        else if(ispunct(c))
            continue;
        //Returns non-zero (true) if c is space alphabetic character,zero else.
        else if( isspace(c))
            continue;
        //Returns non-zero (true) if c is an alphabetic character, zero else.
        else if(isalpha(c)) {
            //Returns non-zero (true) if c is a lower-case alphabetic character,            //zero else.
            if(islower(c)) {
                (*(target+j)) = c;      //Assigning to target
                j++;                    //Increment j value..
            }
            else {
                //Returns non-zero (true) if c is an upper-case \
                alphabetic character, zero else.
                if(isupper(c)) {
                    //Returns a lower-case version of c if it is an \
                    upper-case alphabetic character.
                    (*(target+j)) = (tolower(c));       //Assigning to target
                    j++;
                }
            }
        }
        //Returns non-zero (true) if c is an alphanumeric character,zero else.
        else if(isalnum(c))
            continue;
    }
    *(target+j)='\0';
}

