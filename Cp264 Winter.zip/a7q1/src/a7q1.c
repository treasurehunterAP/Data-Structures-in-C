/*
 ============================================================================
 Name        : a7q1.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

/*
 Name        : a7q1.c  main test driver (partial)
 Author      : HBF
 Version     : 2019-02-17
 */

#include"tree.h"



int main(){

  TNODE *np,*nf, *root = NULL;
  TNODE *n1 = new_node('A');
  TNODE *n2 = new_node('B');
  TNODE*n3 = new_node('C');
  TNODE *n4 = new_node('D');
  TNODE *n5 = new_node('E');
  TNODE*n6 = new_node('F');
  TNODE *n7 = new_node('G');
  n1->left = n2;
  n1->right = n3;
  n2->left = n4;
  n2->right = n5;
  n3->left = n6;
  n3->right = n7;

  root = n1;

  printf("\n");
  printf("Display Tree\n");
  display_tree(root, 0);
  printf("\n-----------------------------------------------------------------------------------");

  int c=get_count(root);
  printf("\nNode Count: %d\n",c);

printf("-----------------------------------------------------------------------------------");
  int h= get_height(root);
  printf("\nTree height: %d\n",h);

printf("-----------------------------------------------------------------------------------");
  printf("\npre-order: ");
  display_preorder(root);

  printf("\n-----------------------------------------------------------------------------------");

  printf("\npost-order: ");
  display_postorder(root);

  printf("\n-----------------------------------------------------------------------------------");

  printf("\nin-order: ");
  display_inorder(root);

printf("\n-----------------------------------------------------------------------------------");

  printf("\niterative_bf_display:");
  iterative_bf_display(root);

 printf("\n-----------------------------------------------------------------------------------");

  char fone='F';
  np = iterative_bf_search(root, fone);
  printf("\niterative_bf_search: %c",fone);
  if (np!=NULL){

    printf("\nfound: %c\n", np->data);
  }
  else{
    printf("\nnot found");
  }

printf("-----------------------------------------------------------------------------------");
  char f='H';
  np = iterative_bf_search(root, f);
  printf("\niterative_bf_search %c",f);
  if (np!=NULL){

    printf("\nfound: %c\n", np->data);
  }
  else{
    printf("\nnot found");
  }
  printf("\n-----------------------------------------------------------------------------------");

  nf=iterative_df_search(root,'G');
  printf("\niterative_df_search: G");

  if (nf!=NULL){

    printf("\nfound: %c\n", nf->data);
  }
  else{
    printf("\nnot found");
  }
  printf("-----------------------------------------------------------------------------------");


  printf("\n");
  printf("\n");
  printf("\n");






  }

