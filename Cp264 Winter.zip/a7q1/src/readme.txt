Name:
ID:
Email:
WorkID: cp264a7
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1 
1. get_count, get_height, clean_tree              [3/3/] 
2. display preorder/inorder/postorder             [3/3/] 
3. iterative_bf_display, iterative_bf_search      [5/5/]
4. iterative_df_search                            [5/5/]

Q2
1. BST search                                     [3/3/]
2. BST insert                                     [4/4/] 
3. BST extract_smallest_node                      [2/3/]
3. BST delete                                     [2/4/]   

Total:                                           [27/30/]

Test result:

Q1 output: (copy the screen output of your test run) 

Display Tree
|___A
    |___C
        |___G
        |___F
    |___B
        |___E
        |___D

-----------------------------------------------------------------------------------
Node Count: 7
-----------------------------------------------------------------------------------
Tree height: 3
-----------------------------------------------------------------------------------
pre-order: A B D E C F G 
-----------------------------------------------------------------------------------
post-order: D E B F G C A 
-----------------------------------------------------------------------------------
in-order: D B E A F C G 
-----------------------------------------------------------------------------------
iterative_bf_display:A B C D E F G 
-----------------------------------------------------------------------------------
iterative_bf_search: F
found: F
-----------------------------------------------------------------------------------
iterative_bf_search H
not found
-----------------------------------------------------------------------------------
iterative_df_search: G
found: G
-----------------------------------------------------------------------------------





Q2 output: (copy the screen output of your test run)

1. declare and initialize a MARKS variable

2. import_data

3. display_inorder
Ali He Pereira Eccles Wang Peters Lamont Parr Koreck Allison Bodnar Smith Suglio Giblett Chabot Sun Dabu Costa Hatch Myrie 
4. display_stats

statistics summary
count          20
mean           77.9
stddev         13.5

5. add_data: Moore,92.0

add_data: Fan,88.0

add_data: Lu,85.0

6. search: Moore

Not Fount

7. remove_data: Wang
record not exit
remove_data: Chabot
record not exit
8. report_data

9. clean
