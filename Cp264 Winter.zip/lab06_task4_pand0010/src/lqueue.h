#ifndef LQUEUE_H_
#define LQUEUE_H_

#include <stdlib.h>
#include <stdio.h>
//#include <malloc.h>

typedef struct node {
  int data;
  struct node *next;
} qnode;

typedef struct queue {
  qnode *front;
  qnode *rear;
} queue;

void enqueue(queue *, int);
int dequeue(queue *);
qnode *dequeue1(queue *);
void dequeue2(queue *, qnode**);
void display(queue);
void clean(queue *);
void move_front_to_rear(queue *target, queue *source);

#endif /* LQUEUE_H_ */
