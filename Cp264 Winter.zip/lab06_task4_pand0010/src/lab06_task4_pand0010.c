/*
 ============================================================================
 Name        : lab06_task4_pand0010.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include <stdlib.h>
#include <stdio.h>
#include "lqueue.h"

int main() {
  int i;
  queue myq = {0};
  myq.front = NULL;
  myq.rear = NULL;
  for (i=1; i<=5; i++) {
     printf("Enqueue value:%d\n", i);
     enqueue(&myq, i);
  }
  printf("\nDisplay all:\n");
  display(myq);

  printf("\n");

  queue myq2 = {0};
  myq2.front = NULL;
  myq2.rear = NULL;
  for (i=1; i<=5; i++) {
     printf("Enqueue value:%d\n", i);
     enqueue(&myq2, i);
  }
  printf("\nDisplay all:\n");
  display(myq2);

  queue *target = &myq;
  queue *source = &myq2;
  move_front_to_rear(target, source);

  printf("\nDisplay all target:\n");
  display(myq);

  printf("\nDisplay all source:\n");
  display(myq2);
}
