/*
 * HBF
*/
#include <stdio.h>
#include <malloc.h>

typedef struct node {
  int data;
  struct node *next;
} qnode;

typedef struct queue {
  qnode *front;
  qnode *rear;
} queue;

void enqueue(queue *, int);
int dequeue(queue *);
qnode *dequeue1(queue *);
void dequeue2(queue *, qnode**);
void display(queue);
void clean(queue *);
