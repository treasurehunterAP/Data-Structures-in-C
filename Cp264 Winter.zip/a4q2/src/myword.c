#include <stdio.h>
#include <stdlib.h>
#include "myword.h"

void set_stopword(char *filename, char *stopwords[]) {
	FILE *fp;
	int i = 0;
	char word_array[MAX_LINE_LEN];
	char delimiters[] = " .,\n\t\r";
	char *token;
	i = 0;
	if ((fp = fopen(filename, "r")) != NULL) {
		while (fgets(word_array, sizeof(word_array), fp) != NULL) {
			token = (char*) strtok(word_array, delimiters);
			i++;
			while (token != NULL) {
				i = (int) (*token - 'a');

				if (*stopwords[i] == '\0') {
					strcat(stopwords[i], ",");
				}
				strcat(stopwords[i], token);
				strcat(stopwords[i], ",");
				token = (char*) strtok(NULL, delimiters);
			}
		}
	}
}

int contain_word(char *stopwords[], char *word) {
	return str_contain_word(stopwords[*word - 'a'], word);
}

int str_contain_word(char *str, char *word) {
	int flag = 0;
	if (str == NULL || word == NULL)
		flag =0 ;

	char temp[MAX_WORD] = { 0 };
	strcat(temp, ",");
	strcat(temp, word);
	strcat(temp, ",");
	if (strstr(str, temp)) {
		flag = 1;
	}
	return flag;
}

int process_word(char *filename, WORDSUMMARY *words, char *stopwords[]) {
	FILE *fp;
	char *word_token;
	const char delimiters[] = " .,;:!()&?-\n\t\r\"\'";
	char line[MAX_LINE_LEN];
	if ((fp = fopen(filename, "r")) != NULL) {
		while (fgets(line, MAX_LINE_LEN, fp) != NULL) {
			words->line_count++;
			lower_case(line);
			trim(line);
			word_token = (char*) strtok(line, delimiters);
			while (word_token != NULL) {
				words->word_count++;
				if ((contain_word(stopwords, word_token) == 0)) {
					int i = 0;
					int flag = 1;
					while (i < words->keyword_count) {
						if (strstr(words->word_array[i].word,
								word_token)) {
							flag = 0;
							words->word_array[i].frequency++;
						}
						i++;
					}
					if (flag) {
						strcpy(words->word_array[words->keyword_count].word,
							word_token);
						words->keyword_count++;
						words->word_array[i].frequency++;
					}
				}
				word_token = (char*) strtok(NULL, delimiters);
			}
		}
	}return 0;
}


int save_to_file(char *filename, WORDSUMMARY *words) {
	FILE *fp;
	int i = 0;
	if ((fp = fopen(filename, "w")) != NULL) {
		fprintf(fp, "%-20s  %8d\n", "Line count", words->line_count);
		fprintf(fp, "%-20s  %8d\n", "Word count", words->word_count);
		fprintf(fp, "%-20s  %8d\n", "Keyword count", words->keyword_count);
		fprintf(fp, "%-18s  %10s\n", "Keyword", "frequency");
		while (i < words->keyword_count) {
			fprintf(fp, "%-20s  %8d\n", words->word_array[i].word,
					words->word_array[i].frequency);

			i++;
		}
	}
	return 0;
}
