/*
============================================================================
 Name        : lab02task1.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>


#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

double circumference(double radius);

double area(double radius);

double hypotenuse(double side1, double side2);

#endif /* FUNCTIONS_H_ */
