/*
 ============================================================================
 Name        : lab02task1.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */



#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
int main(int argc, char *argv[])
{
double r,side1,side2;

r=atof(argv[1]);

printf("The area is %lf, Circumference is %lf ",area(r),circumference(r));
side1=atof(argv[2]);

side2=atof(argv[3]);

printf("The hypotenuse calculated is %lf ",hypotenuse(side1,side2));
}
