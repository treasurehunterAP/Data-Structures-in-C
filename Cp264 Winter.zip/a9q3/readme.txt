Name:Arjun Pandit
ID:170380010
Email:pand0010@mylaurier.ca
WorkID: cp264a9
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1 
1. new_heap, find_index,                  [3/3/] 
2. insert                                 [3/3/] 
3. extract_min                            [3/3/]
4. decrease_key                           [3/3/]

Q2
1. new_node, new_hashtable functions      [3/3/] 
2. search                                 [3/3/] 
3. insert                                 [3/3/]
4. delete                                 [3/3/]  

Q3
1. display_name_value, resolve_assignment [2/3/]
2. infix_to_postfix, evaluate_infix       [2/3/] 
 
Total:                                   [28/30/]
