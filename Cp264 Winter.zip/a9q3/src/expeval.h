#ifndef EXPEVAL_H
#define EXPEVAL_H

#include "hash.h"

typedef struct node {
  int data;
  int type;  //0:integer number; 1:operator;  3: parenthesis
  struct node *next;
} NODE;

// following functions are modified from the corresponding functions of a6q4
// by using hash table to store symbolic name and value
int resolve_assignment(char* statement, hashtable *ht);
int evaluate_infix(char *infixstr, hashtable *ht);
void infix_to_postfix(char *infixstr, NODE **frontp, NODE **rearp, hashtable *ht);

/*
* display hash table data in format of
* name=value
*/
void display_name_value(hashtable *ht);

//following functions are adapted from a6q4
int evaluate_postfix(NODE *front);
int get_priority(char opr);
int is_operator(char op);
int is_symbol(char s);
void trim_space(char *s);
NODE *new_node(int data, int type);
void display_forward(NODE *start);
void clean(NODE **startp);
void push(NODE **topp, NODE *np);
NODE *pop(NODE **topp);
NODE *dequeue(NODE **frontp, NODE **rearp);
void enqueue(NODE **frontp, NODE **rearp, NODE *np);

#endif
