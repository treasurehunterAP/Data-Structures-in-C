/*
 ============================================================================
 Name        : a9q3.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "expeval.h"
#include "hash.h"

int htsize = 10;

int main(int argc, char* args[]) {
  char infilename[40] = "expression.txt";0;
  if (argc >1) strcpy(infilename, args[1]);

  if (argc >2) htsize = atoi(args[2]);

  hashtable *ht = new_hashtable(htsize);

  char line[100];
  char delimiters[] = ";\n";
  char *st;

  FILE *fp = fopen(infilename, "r");
  if (fp == NULL) {
    perror("Error while opening the file.\n");
    return 0;
  }

  while (fgets(line, sizeof(line), fp) != NULL) {
    st = strtok(line, delimiters);
    while (st != NULL) {
      resolve_assignment(st, ht);
      st = strtok(NULL, delimiters);
    }
  }
  fclose(fp);
  display_name_value(ht);
  clean_hash(&ht);

  return 0;
}

/*
expression.txt
a=5;
b=3;
c=(a+b)*(a-b);
b=a+b+c;

gcc hash.c expeval.c a9q3.c
a9q3 expression.txt

a=5
b=24
c=16
*/


