#include "mystring.h"
#include<stdio.h>
#include<stdlib.h>

int str_length(char *s) {
	int counter = 0;
	while (*s != '\0') {
		counter++;
		s++;
	}
	return counter;
}

int word_count(char *s) {
	if (s == NULL || *s == '\0') return 0;
	int w_count = 0;
	char *p = s;
	while (*p) {
		if (*p != ' ' && (p == s || *(p-1) == ' ')) {
			w_count++;
		}
		p++;
	}
	return w_count;
}


void lower_case(char *s) {
	int i = 0;

	while(s[i] != '\0') {
		if (s[i] >= 'A' && s[i] <= 'Z'){
			s[i] = s[i] + 32;
		}
		i++;
	}
}

void trim(char *s) {
	char *p = s, *dp = s;
	while (*p) {
		if  (*p  !=  ' ' || (p > s && *(p -1) != ' ')){
			*dp =*p;
			dp++;
		}
		p++;
	}
	if (*(p - 1) == ' ') {
		*(dp -1) = '\0';
	}
	else {
		*dp = '\0';
	}
}
