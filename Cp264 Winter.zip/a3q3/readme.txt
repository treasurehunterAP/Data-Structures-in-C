Name:Arjun Kumar Pandit
ID:170380010
Email:pand0010@mylaurier.ca
WorkID: cp264a3
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1 
1. bisection method                        [1/3/]
2. correctness of implementation           [3/3/]
3. testing & robustness	                   [2/4/]

Q1 
1. is magic square                         [4/4/]
2. matrix transpose                        [2/2/]
3. matrix multiply                         [4/4/]

Q3
1. length and lower case                   [4/4/]
2. word count                              [3/3/]
3. trim                                    [3/3/]

Total:                                    [26/30/]