#include <stdio.h>
#include <stdlib.h>
#include "simple_bst.h"
tnode *new_node(int data) {
  tnode *np = (tnode *) malloc(sizeof(tnode));
  if (np == NULL) return NULL;
  np->data = data;
  np->left = NULL;
  np->right = NULL;
  return np;
}
//recursive, time complexity O(height), space complexity O(height)
tnode *recursive_search(tnode *root, int val) {
  if (root==NULL) return NULL;
  else if (val == root->data) return root;
  else if (val < root->data) {
    return recursive_search(root->left, val);
  } else {
    return recursive_search(root->right, val);
  }
}

//recursive, time complexity O(height), space complexity O(height)
int recursive_insert(tnode **rootp, int val) {
  if (*rootp == NULL) {
    *rootp = new_node(val);
    if (*rootp) return 1;
    else return 0;
  } else {
    if (val == (*rootp)->data) {
      return 0;
    }
    else if (val < (*rootp)->data)
     return recursive_insert(&(*rootp)->left, val);
    else
     return recursive_insert(&(*rootp)->right, val);
  }
}

//recursive, time complexity O(height), space complexity O(height)
int recursive_delete(tnode **rootp, int val) {
  tnode *root = *rootp, *tnp;
  if (root == NULL) {
    return 0;
  }
  else if(val == root->data ) {
    if(root->left == NULL && root->right == NULL) {
      free(root);
      *rootp = NULL;
    }
    else if (root->left != NULL && root->right == NULL) {
      tnp = root->left;
      free(root);
      *rootp = tnp;
    }
    else if (root->left == NULL && root->right != NULL) {
      tnp = root->right;
      free(root);
      *rootp = tnp;
    }
    else if( root->left!= NULL && root->right != NULL ) {
      tnp = extract_smallest_node(&root->right);
      tnp->left = root->left;
      tnp->right = root->right;
      *rootp = tnp;
      free(root);
    }
    return 1;
  }
  else {
    if(val < root->data) {
      return recursive_delete(&root->left, val);
    }
    else {
      return recursive_delete(&root->right, val);
    }
  }
}


//recursive, time complexity O(height), space complexity O(height)
tnode *extract_smallest_node(tnode **rootp) {
  tnode *root = *rootp;
  if (root == NULL) {
     return NULL;
  }
  else if (root->left == NULL) {
    *rootp = root->right;
    root->left = NULL;
    root->right = NULL;
    return root;
  }
  else {
    return extract_smallest_node(&root->left);
  }
}

//iterative, time complexity O(height), space complexity O(1)
tnode *find_smallest_element(tnode *root) {
  if (root == NULL) return root;
  while (root->left != NULL) root=root->left;
  return root;
}

//iterative, time complexity O(height), space complexity O(1)
tnode *iterative_find_largest_element(tnode *root) {
  if ( root == NULL) return root;
  while (root->right != NULL) root=root->right;
  return root;
}

//iterative algorithm, time complexity O(height), space complexity O(1)
tnode *iterative_search(tnode *root, int val) {
  while (root) {
    if (val == root->data)
       return root;
    else if (val < root->data)
       root = root->left;
        else
      root = root->right;
  }
  return NULL;
}

int iterative_insert(tnode **rootp, int val) {
  if (*rootp == NULL) { *rootp = new_node(val); return 1;}
  else {
    tnode *tnp = *rootp;
    while (1) {
      if (val == tnp->data) {
          printf("\nThe same key value is found");
        return 0;
      }
      else if (val < tnp->data) {
         if (tnp->left == NULL) {
           tnp->left = new_node(val); break;
         }
         else tnp = tnp->left;
      }
      else {
         if (tnp->right == NULL) {
            tnp->right = new_node(val);
          break;
         }
         else tnp = tnp->right;
      }
    }
    return 1;
    }
}

tnode *iterative_extract_smallest_node(tnode **rootp) {
  if (*rootp == NULL) return NULL;

  tnode *tnp = *rootp, *ptnp = NULL;
  while (tnp->left != NULL) {
    ptnp = tnp;
    tnp = tnp->left;
  }

  if (tnp->right == NULL) {
  if (ptnp == NULL)
    *rootp = NULL;
    else
     ptnp->left = NULL;
  } else {
    if (ptnp == NULL)
    *rootp = tnp->right;
  else
    ptnp->left = tnp->right;
  }
  return tnp;
}

int iterative_delete_extract(tnode **rootp, int val) {
  tnode *tnp = *rootp, *ptnp = NULL, *smallest_node;
  // find the node
  while (tnp != NULL && val != tnp->data) {
    ptnp = tnp;
    tnp = (val < tnp->data) ? tnp->left : tnp->right;
  }

  if (tnp == NULL) {  // not found
    printf("Not found");
    return 0;
  }
  else { // found

    if (tnp->right == NULL) {
      if (ptnp == NULL) {
        *rootp = tnp->left;
      }
      else {
        if (ptnp->left == tnp)
          ptnp->left = tnp->left;
        else
          ptnp->right = tnp->left;
      }
    }
    else {
      smallest_node = iterative_extract_smallest_node(&tnp->right);
      if (ptnp == NULL) {
        *rootp = smallest_node;
      }
      else {
        if (ptnp->left == tnp)
      	ptnp->left = smallest_node;
        else
      	ptnp->right = smallest_node;
      }
      smallest_node->left = tnp->left;
      smallest_node->right = tnp->right;
    }
    free(tnp);

    return 1;
  }
}

//iterative, time complexity O(height), space complexity O(1)
int iterative_delete(tnode **rootp, int val) {
  tnode *tnp, *parentp, *suc, *psuc, *ptr;
  if (*rootp == NULL) {
    printf("\nThe tree is empty ");
    return 0;
  }
  else
  {
    //find the node of the given value
    parentp = NULL;
    tnp = *rootp;
    while (tnp != NULL && val != tnp->data) {
      parentp = tnp;
      tnp = (val < tnp->data) ? tnp->left : tnp->right;
    }

    // value node not found
    if (tnp == NULL) {
      printf("\nThe value to be deleted is not present in the tree");
      return 0;
    }

    //tnp->data == val, node tnp will be deleted,
    if (tnp->left == NULL)
      ptr = tnp->right;
    else if (tnp->right == NULL)
      ptr = tnp->left;
    else {
      // find the smallest on right subtree
      psuc = tnp;
      suc = tnp->right;
      while (suc->left != NULL) {
        psuc = suc;
        suc = suc->left;
      }

      if (tnp == psuc) {
        suc->left = tnp->left;
      } else {
        psuc->left = suc->right;
        suc->left = tnp->left;
        suc->right = tnp->right;
      }
      ptr = suc;
    }

  // Attach ptr to the parent node
    if (parentp == NULL)
      *rootp = ptr;
    else if (parentp->left == tnp)
      parentp->left = ptr;
    else
      parentp->right = ptr;

    free(tnp);
  }
}

void clean_tree(tnode **rootp) {
  tnode *root = *rootp;
  if (root) {
    if (root->left)
      clean_tree(&root->left);
    if (root->right)
      clean_tree(&root->right);
    free(root);
  }
  *rootp = NULL;
}

void print_preorder(tnode *root) {
  if (root) {
    printf("%d ", root->data);
    print_preorder(root->left);
    print_preorder(root->right);
  }
}

void print_inorder(tnode * root) {
  if (root) {
    print_inorder(root->left);
    printf("%d ", root->data);
    print_inorder(root->right);
  }
}

void print_postorder(tnode *root) {
  if (root) {
    print_postorder(root->left);
    print_postorder(root->right);
    printf("%d ", root->data);
  }
}

void print_tree(tnode *root, int prelen) {
  int i;
  if (root) {
    for (i = 0; i < prelen; i++) printf("%c", ' ');
    printf("%s", "|___");
    printf("%d\n", root->data);
    print_tree(root->right, prelen + 4);
    print_tree(root->left, prelen + 4);
  }
}
