#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <time.h>

typedef struct node {
  int vertex;
  struct node *next;
} node;

/*
 * generate a random directed graph
*/
void random_graph(node *adj[], int n);

/*
 * make a direct graph bidirectional
*/
void  bidirect_graph(node *adj[], int node_number);
void create_graph(node *adj[], int n);
void display_graph(node *adj[], int n);
int add_edge(node *adj[], int n, int from, int to);
int delete_edge(node *adj[], int n, int from, int to);

void delete_graph(node *adj[], int n);
void breadth_first_search(node *adj[], int size, int visited[], int start);
void depth_first_search_recursive(node *adj[], int size, int visited[], int start);
void depth_first_search_iterative(node *adj[], int size, int visited[], int start);
int reach_count(node *adj[], int size, int start);
void node_counts(node *adj[], int n);
