/*
 ============================================================================
 Name        : lab10_task2.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "graph_al.h"

int main(int argc, char *args[]) {
  int n = 10;
  if (argc >1) n = atoi(args[1]);

    //declear adjacent list
  node *adj[n];
  //initialization graph
  int i;
  for (i = 0; i < n; i++) adj[i] = NULL;

  for (i = 0; i < n-1; i++) {
     add_edge(adj, n, i, i+1);
  }
  add_edge(adj, n, n-1, 0);
  printf("\nDisplay Graph:");
  display_graph(adj, n);
  printf("\nReach count: %d\n", reach_count(adj, n, 0));

  for (i = 0; i < n-1; i++) {
     if (i%2 == 0)
     delete_edge(adj, n, i, i+1);
  }
  printf("\nDisplay Graph:");
  display_graph(adj, n);
  printf("\nReach count: %d\n", reach_count(adj, n, 0));

  delete_graph(adj, n);

  //generate random graph
  random_graph(adj, n);

  //bidirect_graph(adj, n);
  printf("\nDisplay Graph:");
  display_graph(adj, n);

  //declear visited array to be used by DFS and BFS
  int visited[n];
  //initialization of visited array
  for (i=0; i<n; i++) visited[i] = 0;
  printf("\nBFS order:\n");
  //BFS start from 0
  breadth_first_search(adj, n, visited, 0);
  printf("\nvisited by BFS:\n");
  for (i=0; i<n; i++) {
    if (visited[i] == 1) printf("%d ", i);
  }

  //initialization of visited array
  for (i = 0; i < n; i++) visited[i] = 0;
  printf("\nDFS recursive order:\n");
  //DFS start from 0
  depth_first_search_recursive(adj, n, visited, 0);
  printf("\nvisited by DFS:\n");
  for (i=0; i<n; i++) {
     if (visited[i] == 1) printf("%d ", i);
  }

  //initialization of visited array
  for (i = 0; i < n; i++) visited[i] = 0;
  printf("\nDFS iterative order:\n");
  //DFS start from 0
  depth_first_search_iterative(adj, n, visited, 0);
    printf("\nvisited by DFS:\n");
  for (i=0; i<n; i++) {
     if (visited[i] == 1) printf("%d ", i);
  }

  //TASK 4
  printf("\n");
  for(i = 0; i < n; ++i)
  {
    node_counts(adj, i);
  }

  printf("\nReach count: %d\n", reach_count(adj, n, 0));
  delete_graph(adj, n);

  return 0;
}
