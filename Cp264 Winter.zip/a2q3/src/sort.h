#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void diaplay_array(int , int *);
void copy_array(int, int *, int *);
int is_sorted(int, int *);
void selection_sort(int, int *);
void quick_sort(int, int, int *);
void swap(int *, int *);

void display_array(int n, int *a)
{
  int i;
  for (i=0; i<n; ++i) {
    if (i%10 == 0) printf("\n");
      printf("%3d ", *(a+i));
  }
  printf("\n");
}


void copy_array(int n, int *a, int *b)
{
for (int i=0; i<n; i++){
	b[i]=*(a+i);
}
}

int is_sorted(int n, int *a) {
	int i; // 1
	int isSorted = 1;

	for (i = 0; i < n - 1; i++){
		// i=0 (1) + n-1 +n = 1+n-1+n = 2n
		if (*(a+i) > *(a+i+1)){ //2n
			isSorted = 0;
		}
	}
	return isSorted;

	}

void selection_sort(int n, int *a)
{
	int i;
		int k;

		for (i = 0; i < n - 1; i++) {

			int min_idx = i;

			for (k = i + 1; k < n; k++) {
				if (*(a + k) < *(a + min_idx)) {
					min_idx = k;

				}

			}
			if (min_idx != i) {

				swap((a + i), (a + min_idx));
			}


		}

	}



void quick_sort(int m, int n, int *a) {
	int i, j, t, p;
	if (m < n) {
		p = m;
		i = m;
		j = n;
		while (i < j) {
			while (a[i] <= a[p] && i < n)
				i++;
			while (a[j] > a[p])
				j--;
			if (i < j) {
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}
		t = a[p];
		a[p] = a[j];
		a[j] = t;
		quick_sort(m, j - 1, a);
		quick_sort(j + 1, n, a);
	}

}

void swap(int *first, int *second )
{
*first+=*second;
*second=*first-*second;
*first-=*second;
}
