#include "heap.h"
#include "algorithm.h"

EDGELIST *mst_prim(GRAPH *g, int start) {
// your implementation
	if (!g) return NULL;

	int i, heapindex, u, n = g->order;
	int parent[n];
	int visited[n];

	for (i = 0; i < n; i++) visited[i] = 0;
	HNODE *gn;
	HEAP *h = new_heap(4);

	ADJNODE *temp = g->adjlist[start];
	visited[start] = 1;
	while (temp) {
		insert(h, new_hnode(temp->weight, temp->vertex));
		parent[temp->vertex] = start;
		visited[temp->vertex] = 0;
		temp = temp->next;
	}

	EDGELIST *mst = new_edgelist();

	while(h->size > 0) {
		HNODE gn = extract_min(h);
		int u = gn.data;
		visited[u] = 1;
		add_edge_end(mst, parent[u], u, gn.key);
//		free(gn);
		temp = g->adjlist[u];
		while (temp) {
			heapindex = find_index(h, temp->vertex);
			if (heapindex >= 0) {
				if (visited[temp->vertex] == 0 && temp->weight < h->hnap->key) {
					decrease_key(h, heapindex, temp->weight);
					parent[temp->vertex] = u;
				}
			} else {
				if (visited[temp->vertex] == 0) {
					insert(h, new_hnode(temp->weight, temp->vertex));
					parent[temp->vertex] = u;
				}
			}
			temp = temp->next;
		}
	}
	return mst;

}

EDGELIST *spt_dijsktra(GRAPH *g, int start) {
// your implementation
	if (!g) return NULL;
		EDGELIST *spt = new_edgelist();

		//find SPT by Dijsktra's shortest path tree algorithm
	    //add edges to spt

		int i, heapindex, u, n = g->order;

		int parent[n];
		int visited[n];
		int label[n];

		for (i = 0; i < n; i++) {
			visited[i] = 0;
			label[i] = INFINITY;
		}
		HNODE *gn;
		HEAP *h = new_heap(4);
		ADJNODE *temp = g->adjlist[start];
		visited[start] = 1;
		label[start] = 0;
		while (temp) {
			insert(h, new_hnode(temp->weight, temp->vertex));
			parent[temp->vertex] = start;
			visited[temp->vertex] = 0;
			temp = temp->next;
		}

		while(h->size > 0) {
			HNODE gn = extract_min(h);
			int u = gn.data;
			visited[u] = 1;
			add_edge_end(spt, parent[u], u, gn.key);
//			free(gn);
			temp = g->adjlist[u];
			while (temp) {
				heapindex = find_index(h, temp->vertex);
				if (heapindex >= 0) {
					if (visited[temp->vertex] == 0 && temp->weight + label[u] < h->hnap->key) {
						decrease_key(h, heapindex, temp->weight + label[u]);
						parent[temp->vertex] = u;
					}
				} else {
					if (visited[temp->vertex] == 0) {
						insert(h, new_hnode(temp->weight, temp->vertex));
						parent[temp->vertex] = u;
					}
				}
				temp = temp->next;
			}
		}
		return spt;
}

EDGELIST *sp_dijsktra(GRAPH *g, int start, int end) {
// your implementation

	if (!g) return NULL;

		//build SPT by Dijsktra's shortest path tree algorithm, and break after the end node is added

		EDGELIST *sp = new_edgelist();
	    // do back tracking start from end using parent[] and add_elgraph_edge_start

		//find SPT by Dijsktra's shortest path tree algorithm
	    //add edges to spt

		int i, heapindex, u, n = g->order;

		int parent[n];
		int visited[n];
		int label[n];

		for (i = 0; i < n; i++) {
			visited[i] = 0;
			label[i] = INFINITY;
		}
		HEAP *h = new_heap(4);
		ADJNODE *temp = g->adjlist[start];
		visited[start] = 1;
		label[start] = 0;
		while (temp) {
			insert(h, new_hnode(temp->weight, temp->vertex));
			parent[temp->vertex] = start;
			visited[temp->vertex] = 0;
			label[temp->vertex] = label[start] + temp->weight;
			temp = temp->next;
		}
		EDGELIST *spt = new_edgelist();

		while(h->size > 0) {
			HNODE gn = extract_min(h);
			u = gn.data;
			visited[u] = 1;
			add_edge_end(spt, parent[u], u, label[u] - label[parent[u]]);

			if (u == end) break;
//			free(gn);
			temp = g->adjlist[u];

			while (temp) {
				heapindex = find_index(h, temp->vertex);
				if (heapindex >= 0) {
					if (visited[temp->vertex] == 0 && temp->weight + label[u] < h->hnap->key) {
						decrease_key(h, heapindex, temp->weight + label[u]);
						parent[temp->vertex] = u;
						label[temp->vertex] = temp->weight + label[u];
					}
				} else {
					if (visited[temp->vertex] == 0) {
						insert(h, new_hnode(temp->weight + label[u], temp->vertex));
						parent[temp->vertex] = u;
						label[temp->vertex] = temp->weight + label[u];
					}
				}
				temp = temp->next;
			}
		}

		while (u != start) {
			add_edge_start(sp, parent[u], u, label[u] - label[parent[u]]);
			u = parent[u];
		}
		return sp;
}

