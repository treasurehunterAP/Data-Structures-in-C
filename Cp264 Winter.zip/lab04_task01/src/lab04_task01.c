/*
 ============================================================================
 Name        : lab04_task01.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(){
	FILE*pToFile=fopen("data.txt","r"); // pToFile is the name of the pointer that directs you to the file
	int line=0;
	char input[500]; // how many characters are in the file
	while(fgets(input,500,pToFile )!=NULL){
		line++; // increments the line
		printf("Line:%d->%s",line,input);

	}
	printf("\nThe total lines in the file are %d",line);
		fclose(pToFile); //closes the file

	return 0;



}
