#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#define MAX_REC 100
#define MAX_LINE 100
typedef struct {
	char name[20];
	float score;
} RECORD;
char letter_grade(float s);
int import_data(RECORD dataset[], char *filename); //return the number of records
int report_data(RECORD dataset[], int n, char *filename); //return status

char letter_grade(float s){// s=score
	if(s>=85 && s<=100)
		return 'A';
	else if(s>=70 && s<85)
		return 'B';
	else if(s>=60 && s<70)
		return 'C';
	else if(s>=50 && s<=60)
		return 'D';
	else
		return 'F';

}

int import_data(RECORD dataset[], char *filename) {

	FILE *fp;

	fp = fopen(filename, "r");

	if(fp==NULL)

		return 0;

	int n=0;

	char temp[100];

	while(!feof(fp)){

		fscanf(fp, "%s", temp);

		strcpy(dataset[n].name, strtok(temp, ","));

		dataset[n].score = atof(strtok(NULL, ","));

		n++;

	}

	fclose(fp);

	return n;

}


int report_data(RECORD dataset[], int n, char *filename) {
	FILE *fp;

	fp = fopen(filename, "w");

	int i;

	float avg = 0.0;

	for(i=0; i<n; i++){

		fprintf(fp, "%-15s  %c\n ", dataset[i].name, letter_grade(dataset[i].score));

		avg+=dataset[i].score;

	}

	avg /= n;

	float variance = 0.0;

	for(i=0; i<n; i++)

		variance += (avg-dataset[i].score)*(avg-dataset[i].score);

	variance /= (n-1);


	float std_dev = sqrt(variance);

	fprintf(fp, "Record count:%d \n",n);

	fprintf(fp, "Average Score: %.2f \n", avg);

	fprintf(fp, "Standard Deviation: %.2f\n ", std_dev);

	printf("Successfully saved into %s ", filename);

	fclose(fp);

}




