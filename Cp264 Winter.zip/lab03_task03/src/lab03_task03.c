/*
 ============================================================================
 Name        : lab03_task03.c
 Author      : Arjun
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

int main( int argc, char *argv[] ) {
//here argc contains the number of arguments passed via commandline
//argv is the array of arguments which are seperated by space
//argv[0] means first argument is always the file name
//create string to hold the arguments
char str [100] = "";

//loop through all of the arguments
for(int i=1;i<argc;i++){
//concatenate word to the string str
strcat(str,argv[i]);
//concatenate space after each word
strcat(str," ");
}
//printing the output
printf("%s",str);
}
